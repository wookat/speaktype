import{n as e}from"./mic-2XSRiOnH.js";var t=document.querySelector(`#app`);function n(e){t&&(t.innerHTML=e)}var r=`
  <h1>让 SpeakType 用你的麦克风</h1>
  <p>点下面的按钮，然后在浏览器弹出的气泡里选「允许」。授权一次即可，之后在任意网页按住热键就能说话。</p>
  <button id="grant">允许使用麦克风</button>
  <div id="status"></div>
`;function i(e,t){let n=document.querySelector(`#status`);n&&(n.innerHTML=`<div class="status ${e}">${t}</div>`)}async function a(){let t=document.querySelector(`#grant`);t&&(t.disabled=!0);try{let e=await navigator.mediaDevices.getUserMedia({audio:!0});for(let t of e.getTracks())t.stop();i(`ok`,`已授权，可以关掉这个页面回去说话了。`)}catch(n){i(`bad`,`${e(n)?.message??String(n)}<br />若没看到弹窗，多半是之前点过「拒绝」：打开 <code>chrome://settings/content/microphone</code>，把本扩展从「不允许」里移除后再试。`),t&&(t.disabled=!1)}}n(r),document.querySelector(`#grant`)?.addEventListener(`click`,()=>void a());